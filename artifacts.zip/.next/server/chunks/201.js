exports.id = 201;
exports.ids = [201];
exports.modules = {

/***/ 7476:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./de.json": [
		7029,
		29
	],
	"./en.json": [
		9316,
		316
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(() => {
		return __webpack_require__.t(id, 3 | 16);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 7476;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 442:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9708, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2911));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7150))

/***/ }),

/***/ 11:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9147))

/***/ }),

/***/ 2469:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8384))

/***/ }),

/***/ 9147:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Error)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_intl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72);
/* harmony import */ var next_intl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_intl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_PageLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2855);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Error({ error, reset }) {
    const t = (0,next_intl__WEBPACK_IMPORTED_MODULE_3__.useTranslations)("Error");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.error(error);
    }, [
        error
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        title: t("title"),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: t.rich("description", {
                p: (chunks)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "mt-4",
                        children: chunks
                    }),
                retry: (chunks)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "text-white underline underline-offset-2",
                        onClick: reset,
                        type: "button",
                        children: chunks
                    })
            })
        })
    });
}


/***/ }),

/***/ 8384:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ NotFoundPage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_intl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72);
/* harmony import */ var next_intl__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_intl__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_PageLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2855);
/* __next_internal_client_entry_do_not_use__ default auto */ 


// Note that `app/[locale]/[...rest]/page.tsx`
// is necessary for this page to render.
function NotFoundPage() {
    const t = (0,next_intl__WEBPACK_IMPORTED_MODULE_2__.useTranslations)("NotFoundPage");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_PageLayout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        title: t("title"),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "max-w-[460px]",
            children: t("description")
        })
    });
}


/***/ }),

/***/ 2911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Navigation)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next-intl/dist/next-intl.cjs.production.min.js
var next_intl_cjs_production_min = __webpack_require__(72);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(391);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
// EXTERNAL MODULE: ./node_modules/next-intl/dist/src/client/useRouter.js
var useRouter = __webpack_require__(344);
// EXTERNAL MODULE: ./node_modules/next-intl/dist/src/client/usePathname.js
var usePathname = __webpack_require__(2289);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./src/components/LocaleSwitcher.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




function LocaleSwitcher() {
    const t = (0,next_intl_cjs_production_min.useTranslations)("LocaleSwitcher");
    const [isPending, startTransition] = (0,react_.useTransition)();
    const locale = (0,next_intl_cjs_production_min.useLocale)();
    const router = (0,useRouter/* default */.Z)();
    const pathname = (0,usePathname/* default */.Z)();
    function onSelectChange(event) {
        const nextLocale = event.target.value;
        startTransition(()=>{
            router.replace(pathname, {
                locale: nextLocale
            });
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
        className: clsx_default()("relative text-gray-400", isPending && "transition-opacity [&:disabled]:opacity-30"),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "sr-only",
                children: t("label")
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                className: "inline-flex appearance-none bg-transparent py-3 pl-2 pr-6",
                defaultValue: locale,
                disabled: isPending,
                onChange: onSelectChange,
                children: [
                    "en",
                    "de"
                ].map((cur)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                        value: cur,
                        children: t("locale", {
                            locale: cur
                        })
                    }, cur))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "pointer-events-none absolute right-2 top-[8px]",
                children: "⌄"
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/next-intl/dist/src/link/Link.js + 1 modules
var Link = __webpack_require__(3908);
;// CONCATENATED MODULE: ./src/components/NavigationLink.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function NavigationLink({ href, ...rest }) {
    const pathname = (0,usePathname/* default */.Z)();
    const isActive = pathname === href;
    return /*#__PURE__*/ jsx_runtime_.jsx(Link/* default */.Z, {
        "aria-current": isActive,
        className: clsx_default()("inline-block px-2 py-3 transition-colors", isActive ? "text-white" : "text-gray-400 hover:text-gray-200"),
        href: href,
        ...rest
    });
}

;// CONCATENATED MODULE: ./src/components/Navigation.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Navigation() {
    const t = (0,next_intl_cjs_production_min.useTranslations)("Navigation");
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-slate-850",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
            className: "container flex justify-between px-2 py-2 text-white",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(NavigationLink, {
                            href: "/",
                            children: t("home")
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(NavigationLink, {
                            href: "/about",
                            children: t("about")
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(LocaleSwitcher, {})
            ]
        })
    });
}


/***/ }),

/***/ 2855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ PageLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next-intl/dist/next-intl.cjs.production.min.js
var next_intl_cjs_production_min = __webpack_require__(72);
;// CONCATENATED MODULE: ./src/components/ExternalLink.tsx

function ExternalLink({ description, href, title }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
        className: "inline-block rounded-md border border-gray-700 p-8 transition-colors hover:border-gray-400",
        href: href,
        rel: "noreferrer",
        target: "_blank",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "text-xl font-semibold text-white",
                children: [
                    title,
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "ml-2 inline-block",
                        children: "→"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "mt-2 max-w-[250px] text-gray-400",
                children: description
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/components/PageLayout.tsx



function PageLayout({ children, title }) {
    const t = (0,next_intl_cjs_production_min.useTranslations)("PageLayout");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative flex grow flex-col bg-slate-850 py-36",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute inset-0 overflow-hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "absolute left-0 top-1 h-[20500px] w-[20500px] -translate-x-[47.5%] rounded-full bg-gradient-to-b from-slate-900 via-cyan-500"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container relative flex grow flex-col px-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-3xl font-semibold leading-tight tracking-tight text-white md:text-5xl",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-6 text-gray-400 md:text-lg",
                        children: children
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-auto grid grid-cols-1 gap-4 pt-20 md:grid-cols-2 lg:gap-12",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ExternalLink, {
                                description: t("links.docs.description"),
                                href: t("links.docs.href"),
                                title: t("links.docs.title")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ExternalLink, {
                                description: t("links.source.description"),
                                href: t("links.source.href"),
                                title: t("links.source.title")
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 5754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/weikding/Desktop/example-next-13/src/app/[locale]/error.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 3393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ LocaleLayout),
  generateMetadata: () => (/* binding */ generateMetadata),
  generateStaticParams: () => (/* binding */ generateStaticParams)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src/app/[locale]/layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(9507);
var layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.js
var clsx = __webpack_require__(7369);
var clsx_default = /*#__PURE__*/__webpack_require__.n(clsx);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(4980);
// EXTERNAL MODULE: ./node_modules/use-intl/dist/src/core/createTranslator.js + 6 modules
var createTranslator = __webpack_require__(464);
// EXTERNAL MODULE: ./node_modules/next-intl/dist/src/shared/NextIntlClientProvider.js
var NextIntlClientProvider = __webpack_require__(6754);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/components/Navigation.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/weikding/Desktop/example-next-13/src/components/Navigation.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navigation = (__default__);
;// CONCATENATED MODULE: ./src/app/[locale]/layout.tsx






async function getMessages(locale) {
    try {
        return (await __webpack_require__(7476)(`./${locale}.json`)).default;
    } catch (error) {
        (0,navigation.notFound)();
    }
}
async function generateStaticParams() {
    return [
        "en",
        "de"
    ].map((locale)=>({
            locale
        }));
}
async function generateMetadata({ params: { locale } }) {
    const messages = await getMessages(locale);
    // You can use the core (non-React) APIs when you have to use next-intl
    // outside of components. Potentially this will be simplified in the future
    // (see https://next-intl-docs.vercel.app/docs/next-13/server-components).
    const t = (0,createTranslator/* default */.Z)({
        locale,
        messages
    });
    return {
        title: t("LocaleLayout.title")
    };
}
async function LocaleLayout({ children, params: { locale } }) {
    const messages = await getMessages(locale);
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        className: "h-full",
        lang: locale,
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            className: clsx_default()((layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className, "flex h-full flex-col"),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(NextIntlClientProvider/* default */.ZP, {
                locale: locale,
                messages: messages,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Navigation, {}),
                    children
                ]
            })
        })
    });
}


/***/ }),

/***/ 8166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/weikding/Desktop/example-next-13/src/app/[locale]/not-found.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;